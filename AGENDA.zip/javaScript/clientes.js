document.addEventListener("DOMContentLoaded", () => {
  const listaClientes = document.getElementById("listaClientes");
  const topClientes = document.getElementById("topClientes");
  const inputBusca = document.getElementById("inputBuscaCliente");
  const tituloLista = document.getElementById("tituloListaClientes");

  const modalCliente = document.getElementById("modalCliente");
  const btnNovoCliente = document.getElementById("btnNovoCliente");
  const btnCancelarCliente = document.getElementById("btnCancelarCliente");
  const btnSalvarCliente = document.getElementById("btnSalvarCliente");
  const btnVerRanking = document.getElementById("btnVerRanking");
  const btnOrdenarClientes = document.getElementById("btnOrdenarClientes");
  const cardAniversariantes = document.getElementById("cardAniversariantes");
  const cardClientesSumidos = document.getElementById("cardClientesSumidos");

  const inputNomeCliente = document.getElementById("inputNomeCliente");
  const inputTelefoneCliente = document.getElementById("inputTelefoneCliente");
  const inputDiaAniversario = document.getElementById("inputDiaAniversario");
  const inputMesAniversario = document.getElementById("inputMesAniversario");
  const inputAnoAniversario = document.getElementById("inputAnoAniversario");
  const inputObservacaoCliente = document.getElementById("inputObservacaoCliente");

  let clientes = [];
  let filtroAtual = "todos";
  let ordenacaoAtual = "faturamento";

  iniciar();

  function iniciar() {
    sincronizarClientesComAgenda();
    carregarClientes();
    configurarEventos();
  }

  function configurarEventos() {
    inputBusca.addEventListener("input", () => aplicarFiltro("busca"));
    btnNovoCliente.addEventListener("click", abrirModalCliente);
    btnCancelarCliente.addEventListener("click", fecharModalCliente);
    btnSalvarCliente.addEventListener("click", salvarCliente);
    btnVerRanking.addEventListener("click", () => aplicarFiltro("ranking"));
    cardAniversariantes.addEventListener("click", () => aplicarFiltro("aniversariantes"));
    cardClientesSumidos.addEventListener("click", () => aplicarFiltro("sumidos"));
    btnOrdenarClientes.addEventListener("click", alternarOrdenacao);

    modalCliente.addEventListener("click", (e) => {
      if (e.target === modalCliente) fecharModalCliente();
    });
  }

  function carregarClientes() {
    const clientesCadastrados = JSON.parse(localStorage.getItem("clientes")) || [];
    const estatisticas = gerarEstatisticasClientes();

    clientes = clientesCadastrados.map((cliente) => {
      const dados = estatisticas[normalizarTexto(cliente.nome)] || {
        atendimentos: 0,
        totalGasto: 0,
        ultimaVisita: null,
      };

      return { ...cliente, ...dados };
    });

    atualizarResumo();
    renderizarTopClientes();
    aplicarFiltro(filtroAtual);
  }

  function aplicarFiltro(tipo = filtroAtual) {
    filtroAtual = tipo === "busca" ? filtroAtual : tipo;
    const termo = normalizarTexto(inputBusca.value);
    let lista = [...clientes];

    if (filtroAtual === "ranking") lista.sort((a, b) => b.totalGasto - a.totalGasto);
    if (filtroAtual === "aniversariantes") lista = lista.filter(ehAniversarianteDoMes);
    if (filtroAtual === "sumidos") lista = lista.filter(ehClienteSumido);

    if (termo) {
      lista = lista.filter((cliente) =>
        normalizarTexto(cliente.nome).includes(termo) ||
        normalizarTexto(cliente.telefone).includes(termo),
      );
    }

    lista = ordenarClientes(lista);
    atualizarTituloLista();
    renderizarClientes(lista);
  }

  function alternarOrdenacao() {
    ordenacaoAtual = ordenacaoAtual === "faturamento" ? "nome" : "faturamento";
    aplicarFiltro();
  }

  function ordenarClientes(lista) {
    if (ordenacaoAtual === "nome") {
      return lista.sort((a, b) => a.nome.localeCompare(b.nome));
    }
    return lista.sort((a, b) => b.totalGasto - a.totalGasto);
  }

  function atualizarTituloLista() {
    const titulos = {
      todos: "Todos os clientes",
      ranking: "Ranking completo",
      aniversariantes: "Aniversariantes",
      sumidos: "Clientes sem retornar",
    };

    tituloLista.textContent = titulos[filtroAtual] || "Todos os clientes";
  }

  function atualizarResumo() {
    document.getElementById("totalClientes").textContent = clientes.length;
    document.getElementById("totalAniversariantes").textContent = clientes.filter(ehAniversarianteDoMes).length;
    document.getElementById("totalClientesSumidos").textContent = clientes.filter(ehClienteSumido).length;
  }

  function renderizarTopClientes() {
    const top3 = [...clientes].sort((a, b) => b.totalGasto - a.totalGasto).slice(0, 3);
    topClientes.innerHTML = "";

    if (top3.length === 0) {
      topClientes.innerHTML = `<p class="clientes-vazio">Nenhum cliente realizado ainda.</p>`;
      return;
    }

    top3.forEach((cliente, index) => {
      topClientes.insertAdjacentHTML("beforeend", `
        <article class="clientes-top-item">
          <div class="medalha medalha-${index + 1}">${index + 1}</div>
          <div class="cliente-avatar">${iniciais(cliente.nome)}</div>
          <div>
            <div class="cliente-nome">${cliente.nome}</div>
            <div class="cliente-sub">${cliente.atendimentos} visitas</div>
          </div>
          <div class="cliente-valor">${formatarMoeda(cliente.totalGasto)}<span>faturados</span></div>
        </article>
      `);
    });
  }

  function renderizarClientes(lista) {
    listaClientes.innerHTML = "";

    if (lista.length === 0) {
      listaClientes.innerHTML = `<div class="clientes-vazio">Nenhum cliente encontrado</div>`;
      return;
    }

    lista.forEach((cliente) => {
      const ultimaVisita = cliente.ultimaVisita
        ? `Última visita há ${calcularDiasDesde(cliente.ultimaVisita)} dias`
        : "Sem visitas realizadas";

      listaClientes.insertAdjacentHTML("beforeend", `
        <article class="cliente-lista-item">
          <div class="cliente-avatar">${iniciais(cliente.nome)}<span class="cliente-status"></span></div>
          <div>
            <div class="cliente-nome">${cliente.nome}</div>
            <div class="cliente-sub">${ultimaVisita}</div>
          </div>
          <div class="cliente-valor">${formatarMoeda(cliente.totalGasto)}<span>${cliente.atendimentos} visitas</span></div>
          <div class="cliente-seta">›</div>
        </article>
      `);
    });
  }

  function abrirModalCliente() {
    inputNomeCliente.value = "";
    inputTelefoneCliente.value = "";
    inputDiaAniversario.value = "";
    inputMesAniversario.value = "";
    inputAnoAniversario.value = "";
    inputObservacaoCliente.value = "";
    modalCliente.classList.add("ativo");
    setTimeout(() => inputNomeCliente.focus(), 80);
  }

  function fecharModalCliente() {
    modalCliente.classList.remove("ativo");
  }

  function salvarCliente() {
    const nome = inputNomeCliente.value.trim();
    if (!nome) return alert("Informe o nome do cliente.");

    const clientesCadastrados = JSON.parse(localStorage.getItem("clientes")) || [];
    const clienteJaExiste = clientesCadastrados.some(
      (cliente) => normalizarTexto(cliente.nome) === normalizarTexto(nome),
    );

    if (clienteJaExiste) return alert("Cliente já cadastrado.");

    clientesCadastrados.push({
      id: Date.now(),
      nome,
      telefone: inputTelefoneCliente.value.trim(),
      aniversarioDia: inputDiaAniversario.value.trim(),
      aniversarioMes: inputMesAniversario.value.trim(),
      aniversarioAno: inputAnoAniversario.value.trim(),
      observacao: inputObservacaoCliente.value.trim(),
    });

    localStorage.setItem("clientes", JSON.stringify(clientesCadastrados));
    fecharModalCliente();
    carregarClientes();
  }

  function sincronizarClientesComAgenda() {
    const clientesCadastrados = JSON.parse(localStorage.getItem("clientes")) || [];
    const nomesCadastrados = clientesCadastrados.map((cliente) => normalizarTexto(cliente.nome));
    const estatisticas = gerarEstatisticasClientes();

    Object.values(estatisticas).forEach((clienteAgenda) => {
      const nomeNormalizado = normalizarTexto(clienteAgenda.nome);
      if (nomesCadastrados.includes(nomeNormalizado)) return;

      clientesCadastrados.push({
        id: Date.now() + Math.floor(Math.random() * 1000),
        nome: clienteAgenda.nome,
        telefone: "",
        aniversarioDia: "",
        aniversarioMes: "",
        aniversarioAno: "",
        observacao: "",
      });
      nomesCadastrados.push(nomeNormalizado);
    });

    localStorage.setItem("clientes", JSON.stringify(clientesCadastrados));
  }

  function gerarEstatisticasClientes() {
    const mapa = {};

    for (let i = 0; i < localStorage.length; i++) {
      const chave = localStorage.key(i);
      if (!chave || !chave.startsWith("agenda_")) continue;

      const data = chave.replace("agenda_", "");
      const agenda = JSON.parse(localStorage.getItem(chave)) || [];

      agenda.forEach((item) => {
        if (item.status !== "realizado" || !item.cliente) return;
        const nome = item.cliente.trim();
        const chaveCliente = normalizarTexto(nome);

        if (!mapa[chaveCliente]) {
          mapa[chaveCliente] = { nome, atendimentos: 0, totalGasto: 0, ultimaVisita: data };
        }

        mapa[chaveCliente].atendimentos++;
        mapa[chaveCliente].totalGasto += Number(item.valor || 0);
        if (data > mapa[chaveCliente].ultimaVisita) mapa[chaveCliente].ultimaVisita = data;
      });
    }

    return mapa;
  }

  function ehAniversarianteDoMes(cliente) {
    return Number(cliente.aniversarioMes) === new Date().getMonth() + 1;
  }

  function ehClienteSumido(cliente) {
    return cliente.ultimaVisita ? calcularDiasDesde(cliente.ultimaVisita) >= 60 : false;
  }

  function calcularDiasDesde(dataTexto) {
    const hoje = new Date();
    const data = criarDataLocal(dataTexto);
    hoje.setHours(0, 0, 0, 0);
    data.setHours(0, 0, 0, 0);
    return Math.max(0, Math.floor((hoje - data) / 86400000));
  }

  function criarDataLocal(dataStr) {
    const [ano, mes, dia] = dataStr.split("-").map(Number);
    return new Date(ano, mes - 1, dia);
  }

  function formatarMoeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }

  function iniciais(nome) {
    return String(nome || "?")
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((parte) => parte[0])
      .join("")
      .toUpperCase();
  }

  function normalizarTexto(texto) {
    return String(texto || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  }
});
